<?php

echo "hello world!";

?>